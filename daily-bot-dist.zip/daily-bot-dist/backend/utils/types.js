// 与前端共享的类型定义
export {};
//# sourceMappingURL=types.js.map